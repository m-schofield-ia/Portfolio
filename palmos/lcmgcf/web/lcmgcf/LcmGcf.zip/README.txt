LcmGcf
======


In LcmGcf you practice solving LCMs and GCFs of two or three numbers. LCM is
the Least Common Multiple and GCF is the Greatest Common Factor.
You setup the characteristica of the quiz - if it should be timed, what kind
of operations you'd like, sizes of the operands and the like.
LcmGcf will then display a LCM or a GCF for you to solve.  LcmGcf keeps
tracks of your successes and failures.
The Last 10 scores can be exported to Memo Pad.

LcmGcf is released under the GNU General Public License v2.

LcmGcf and User Manual can be found at:

	http://www.schau.com/



Thank you for taking the time to evaluate LcmGcf.




Brian Schau <brian@schau.com>


