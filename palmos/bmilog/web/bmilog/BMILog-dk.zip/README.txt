BMILog
======



Disclaimer: This BMI Logger is provided for your information only. It is not
a substitute for professional medical advice, and may not represent your true
individual medical situation.
It does not take all possible factors into account in its assessment of your
healthy weight.
For example, it tends to overestimate body fat in very muscular individuals or
in people who are less than 150 cm. (5 feet) tall, and may underestimate body
fat in people who have lost muscle mass, such as the elderly.
Do not use this information to make significant changes in your diet, exercise
regimen, or other aspects of your lifestyle without consulting your personal
physician or other qualified health care provider as recommended by your
physician.
Please contact your physician if you have any questions or concerns.



Legal Stuff:

BMILog comes as is - if it breaks you get to keep both pieces.  BMILog is
free to use.  Look in LICENSE.txt for legalities.


BMILog, User Manual and a FAQ can be found at:

	http://www.schau.com/bmilog/index.html


A free conduit for BMILog can be downloaded from the website as well.


Thanks for taking the time to evaluate BMILog.


Brian Schau <Brian@Schau.com>


