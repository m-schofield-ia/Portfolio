MathAce
=======


In MathAce you can train simple math - addition, subtraction, multiplication
and division.
You setup the characteristica of the quiz - if it should be timed, what kind
of operations you'd like, sizes of the operands, size of the answer and if
you'd like negative numbers to be in the quiz.
MathAce will then display a simple equation for you to solve.  MathAce keeps
tracks of your successes and failures.
The Last 10 scores can be exported to Memo Pad.

MathAce is released under the GNU General Public License v2.

MathAce and User Manual can be found at:

	http://www.schau.com/s/mathace/index.html



Thank you for taking the time to evaluate MathAce.




Brian Schau <brian@schau.com>


