@Tracker
========


@Tracker is a small time tracker utility.  It can be used to track
tasks, the duration of the task and the start date of the task.
Highlights:

* Easy entry of task, date and duration.
* Simple statistics can be retrieved using a range of criterias.
* Archive and de-archive functions.
* Color coding on capable devices.
 

@Tracker, User Manual and a free tool to manipulate archives can be found at:

	http://www.schau.com/attracker/index.html



Thank you for taking the time to evaluate @Tracker.




Brian Schau <brian@schau.com>


