TasksSort
=========

The builtin Tasks PIM in Palm OS 5 has limited sorting options - it lacks the
option to sort alphabetically on the Description field.
TasksSort can do that.

TasksSort can be set up so that you can launch it from within the Tasks
program, sort the Tasks database and then return to the Tasks program.

TasksSort requires OS 5 or better and have been tested on the Palm TX and
Palm Z22 handhelds.

TasksSort is released under the GNU General Public License v2.

TasksSort and documentation can be found at:

	http://www.schau.com/


Thank you for taking the time to evaluate TasksSort.


Brian Schau <brian@schau.com>


