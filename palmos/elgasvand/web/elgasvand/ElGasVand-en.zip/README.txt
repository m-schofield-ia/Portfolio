El, Gas, Vand
=============

Every month I record the current state of my electricity, gas and water meters.
Normally I record them on a web page on my website.  But then I got the
striking idea of hacking this little program.
It really doesn't do anything useful.  Yet.   I plan to be able to export the
data to csv for later manipulation in Excel or OpenOffice Spreadsheet.
But that is the future .... :-)


Brian Schau <brian@schau.com>

