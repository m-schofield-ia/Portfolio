Gone Mad!
=========

Read and write interesting short stories with Gone Mad!   Start by selecting a
template, which contains some blanks for you to fill in.  Enter words that fit
the descriptions.  The more creative you are, the crazier the final story will
turn out.
After completing all of the blanks, the final story will be displayed,
containing the words you filled in.  If you like your version of the story, you
can export it to Memo Pad.

Once you're familiar with filling in the sample templates, you can begin to
make your own story templates.    Enter the title as the first line of the
story.    As you enter your story, simply leave out key words and replace
them with a description of the missing words in brackets.     For example:

    "I wore a [adjective] shirt to the [event]."

Each of the descriptors in brackets need to be uniquely named, otherwise the
same word will be placed in same-named brackets.
You can even import stories from Memo Pad into Gone Mad!

Gone Mad! is released under the GNU General Public License v2.

Gone Mad! and documentation can be found at:

	http://www.schau.com/s/gonemad/index.html


Tony Vincent has created a Gone Mad! support site.   On his site you can read
various tips and tricks which will help you take advantage of Gone Mad!
Furthermore, Tony keeps a repository of Story Templates.
You can find his Gone Mad! site at:

	http://www.learninginhand.com/GoneMad/

Also visit Tonys other pages at:

	http://www.learninginhand.com/


Thank you for taking the time to evaluate Gone Mad!




Brian Schau <brian@schau.com>


