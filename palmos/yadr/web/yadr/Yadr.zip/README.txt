Yadr
====

Yadr ("Yet Another Document Reader") is used to read the popular DOC format
on your Palm Handheld.   Currently Yadr only supports the Doc format, but
support for other formats are planned.
Yadr can read documents in both memory or on a MMC card (only the first card
detected).
Other highlights of Yadr are: bookmarks and customization of fonts, colors
etc.

Yadr is released under the GNU General Public License v2.
The icons was created by Tony Vincent - please visit his website at:

	http://www.learninginhand.com/

Yadr and documentation can be found at:

	http://www.schau.com/


Thank you for taking the time to evaluate Yadr.


Brian Schau <brian@schau.com>


