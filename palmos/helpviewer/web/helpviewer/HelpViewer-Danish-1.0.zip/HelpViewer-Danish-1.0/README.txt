Plua Help Viewer
================


The Plua Help Viewer is a utility used to view the Help Files distributed
with the Palm Lua programming language.
The Help Viewer reads both Plua1x and Plua2x help files.


Legal Stuff:

Plua Help Viewer comes as is - if it breaks you get to keep both pieces.
Plua Help Viewer is free to use.  Look in LICENSE.txt for legalities.


Plua Help Viewer, User Manual and a small faq can be found at:

	http://www.schau.com/



Thank you for taking the time to evaluate Plua Help Viewer.




Brian Schau <brian@schau.com>


