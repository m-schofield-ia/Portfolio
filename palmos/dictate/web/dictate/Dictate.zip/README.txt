Dictate
=======


Dictate can help students become better spellers.  A teacher assigns sentences
into groups.   A group is dictated to the student which enters what he/she
hears.
Dictate keeps score of correctly entered sentences and more.
After a dictation is over the student can export the results to the memopad
or print out the score using Diploma (http://www.schau.com/s/dictate/index.html)
Dictate is released under the GNU General Public License v2.

Dictate, Diploma and documentation can be found at:

	http://www.schau.com/s/dictate/index.html



Thank you for taking the time to evaluate Dictate.




Brian Schau <brian@schau.com>


