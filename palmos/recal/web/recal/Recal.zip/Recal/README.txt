Recal
=====


Legal Stuff:

Recal comes as is - if it breaks you get to keep both pieces.
Recal is free to use.



To install Recal:

1) Start the standard Palm Install tool.
2) Select 'Add'.
3) Browse to 'recal.prc'.  Highlight 'recal.prc' and press 'open'.
4) Make sure that the Hotsync Manager is running.
5) Insert your Palm in the Craddle and start Hotsync.



To build Recal:

1) You need to have the gcc tool chain installed.
2) You also need to have lmake installed (see http://www.schau.com/)
3) lmake initall
4) lmake





Recal can be found at:

	http://www.schau.com/p/recal/index.html





Thanks for taking the time to evaluate Recal.


Brian Schau  <brian@schau.com>
