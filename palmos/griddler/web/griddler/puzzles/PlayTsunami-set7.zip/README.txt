PlayTsunami Set 7
-----------------

These puzzles are from Rachel Benns wonderful site:

	http://www.playtsunami.com


The puzzles are compatible with Griddler for Palm OS:

	http://www.schau.com/


To install:

	* Open the Palm OS quick install program.
	* Select the PlayTsunami-set1.pdb.
	* Perform a HotSync.


Thanks for playing these puzzles.   Please visit Rachel Benns site ...!


/brian
