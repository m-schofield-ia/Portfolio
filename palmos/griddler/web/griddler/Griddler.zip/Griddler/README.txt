Griddler
========

Griddler lets you play Nonograms, Pic-a-pix's, PictureLogics etc. etc.   A set
of default puzzles are included with Griddler in the PlayTsunami.pdb file.
Also, a program to create puzzles can be found in the PuzzleCvt folder.


Griddler is released under the GNU General Public License v2.

Griddler and documentation can be found at:

	http://www.schau.com/


Thank you for taking the time to evaluate Griddler.


Brian Schau <brian@schau.com>


