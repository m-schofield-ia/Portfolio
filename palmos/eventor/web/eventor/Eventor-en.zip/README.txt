Eventor
=======
 

Please do a HotSync of your Palm before installing this version of Eventor.

If you are using the Eventor Conduit you must install the matching conduit
as well.

Installation order:

1) HotSync your PDA using the old conduit.
2) Install Eventor-2r1 and run it once.
3) Install EventorConduit-2r1.
4) HotSync using the new conduit.


Legal Stuff:

Eventor comes as is - if it breaks you get to keep both pieces.  Eventor is
free to use.  Look in LICENSE.txt for legalities.


Eventor, User Manual and a small faq can be found at:

	http://www.schau.com/eventor/index.html


A free conduit for Eventor can be downloaded from the website as well.


Thanks for taking the time to evaluate Eventor.

Brian Schau <Brian@Schau.com>


