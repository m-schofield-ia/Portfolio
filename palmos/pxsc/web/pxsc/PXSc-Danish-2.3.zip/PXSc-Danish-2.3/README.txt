Phase 10 Score Card
===================


Phase 10 Score Card (PXSc) is an electronic scorecard for the card game
Phase 10 by Ravensburger Spielverlag.
PXSc is not meant to be a substitute for the real game - you must own a
copy of Phase 10 for PXSc to be of any interest to you.


Legal Stuff:

PXSc comes as is - if it breaks you get to keep both pieces. PXSc is
free to use.  Look in LICENSE.txt for legalities.


PXSc, User Manual and a small faq can be found at:

	http://www.schau.com/



Thank you for taking the time to evaluate PXSc.




Brian Schau <brian@schau.com>


