MixedUp
=======


MixedUp is a simple learning tool. In MixedUp you must convert fractions to
mixed number or vice versa.
Each correct conversion you score 1 point.
MixedUp is released under the GNU General Public License v2.

MixedUp and User Manual can be found at:

	http://www.schau.com/s/mixedup/index.html



Thank you for taking the time to evaluate MixedUp.




Brian Schau <brian@schau.com>


