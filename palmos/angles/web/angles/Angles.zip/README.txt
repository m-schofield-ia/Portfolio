Angles
======


Angles is is simple learning tool. Angles takes you through 10 small quizzes
where you have to guess the angle between two lines.
Angles is released under the GNU General Public License v2.

Angles and User Manual can be found at:

	http://www.schau.com/s/angles/index.html



Thank you for taking the time to evaluate Angles.




Brian Schau <brian@schau.com>


