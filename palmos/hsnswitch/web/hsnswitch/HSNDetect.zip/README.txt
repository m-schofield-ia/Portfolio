HSNDetect
=========


If for some reason HSNSwitch (http://www.schau.com/p/hsnswitch/index.html)
fails to detect the HotSync name record it might help me having a trace of
the 'psys' preferences.
HSNDetect wraps those into a nice database file which can be sent to me.

To use:

1) Install HSNDetect.
2) Run it.
3) Do a full HotSync.
4) Mail the "HSND_HSNDetectData.pdb" file to me. You will find the file
   in your backup directory (usually c:\Program Files\palmOne\{id}\backup).

The "Collecting data" phase may take some time.  The slot value goes up to
65535.   Please let it run.   On my Tungsten T it takes around 2 minutes to
complete.

HSNDetect can be found at:

	http://www.schau.com/p/hsnswitch/hsndetect.html




Brian Schau <brian@schau.com>


