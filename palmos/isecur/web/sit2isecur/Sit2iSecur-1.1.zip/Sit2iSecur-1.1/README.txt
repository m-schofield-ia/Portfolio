Sit2iSecur
==========

Sit2iSecur is used to copy your secrets and templates from Secure It to
iSecur.
It is preferred that the copying is done to an empty database in iSecur -
but this is no requirement.
Sit2iSecur will try to copy category information across from Secure It
to iSecur - if there is no more room for new categories, secrets belonging
to such a category are placed in the Unfiled category.

Templates will be copied to a category called Templates. Failing that, they
will be placed in the Unfiled category.

Nothing will be deleted in Secure It.

Sit2iSecur is released under the GNU General Public License v2.


Sit2iSecur and documentation can be found at:

	http://www.schau.com/


Thank you for taking the time to evaluate Sit2iSecur.


Brian Schau <brian@schau.com>


