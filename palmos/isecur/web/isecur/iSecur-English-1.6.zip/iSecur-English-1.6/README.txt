iSecur
======

iSecur is a Personal Information Manager which let you store secrets safely.
iSecur is the successor of Secure It and provides stronger encryption (SHA256
and AES), icons, intelligent templates and more.

The iSecur Icons LoRes and iSecur Icons HiRes files are kindly provided by
Leslie Franke (http://lesliefranke.com)

To use the secrets and templates from Secure It you must transfer them from
Secure It to iSecur using the Sit2iSecur application found on my website at:

	http://www.schau.com/


iSecur is released under the GNU General Public License v2.

iSecur and documentation can be found at:

	http://www.schau.com/


Thank you for taking the time to evaluate iSecur.


Brian Schau <brian@schau.com>


