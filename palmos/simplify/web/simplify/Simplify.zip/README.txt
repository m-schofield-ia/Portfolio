Simplify
========


Simplify is a simple learning tool. In Simplify you must reduce fractions. For
each correct fraction reduced you score 1 point.
Simplify is released under the GNU General Public License v2.

Simplify and User Manual can be found at:

	http://www.schau.com/s/simplify/index.html



Thank you for taking the time to evaluate Simplify.




Brian Schau <brian@schau.com>


